package com.vehicle;

/**Represents a Motorcycle, a type of Vehicle.**/
public class Motorcycle extends Vehicle {
    public Motorcycle(String vehicleId, String model, double pricePerDay, boolean available) {
        super(vehicleId, model, pricePerDay, available);
    }
}



