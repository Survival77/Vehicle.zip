package com.vehicle;

/**Represents a Car, a type of Vehicle.**/
public class Car extends Vehicle {
    public Car(String vehicleId, String model, double pricePerDay, boolean available) {
        super(vehicleId, model, pricePerDay, available);
    }
}


